# SIMPA

Sistema em Python conectado a PostgreSQL na nuvem usando Neon.

## Requisitos

Python 3 instalado.

## Como rodar

1. Abra o terminal na pasta do projeto.

2. Crie o ambiente virtual:

```bash
python -m venv .venv